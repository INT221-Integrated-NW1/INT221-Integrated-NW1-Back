package sit.int221.nw1.dto.requestDTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class JwtDTO {
    @NotBlank
    @Size(max=50)
    private String username;

    @Size(min = 8 , max = 14)
    @NotBlank
    private String password;
}
