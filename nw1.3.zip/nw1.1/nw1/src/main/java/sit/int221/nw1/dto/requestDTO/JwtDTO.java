package sit.int221.nw1.dto.requestDTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class JwtDTO {
    @Size( max = 50, message = "size must be between 0 and 50")
    @NotNull(message = "must not be null")
    @NotBlank(message = "must not be blank")
    private String userName;
    @NotNull(message = "must not be null")
    @Size(max = 14, message = "size must be between 0 and 14")
    @NotBlank(message = "must not be blank")
    private String password;
}
