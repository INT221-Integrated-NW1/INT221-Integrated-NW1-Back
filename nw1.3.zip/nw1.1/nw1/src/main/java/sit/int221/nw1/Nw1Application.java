package sit.int221.nw1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Date;
import java.util.TimeZone;

@SpringBootApplication
public class Nw1Application {

	public static void main(String[] args) {
		SpringApplication.run(Nw1Application.class, args);
	}

}
