package sit.int221.nw1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Nw1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
