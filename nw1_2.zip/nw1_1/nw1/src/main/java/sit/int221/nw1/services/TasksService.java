package sit.int221.nw1.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;

import org.springframework.web.server.ResponseStatusException;
import sit.int221.nw1.entities.Tasks;
import sit.int221.nw1.repositories.TasksRepository;

import java.util.List;

@Service
public class TasksService {
    @Autowired
    private TasksRepository repository;

    public List<Tasks> getAllTasks() {
        return repository.findAll();
    }

    public Tasks findById(Integer id){
        return repository.findById(id).orElseThrow(
                ()-> new ResponseStatusException(HttpStatus.NOT_FOUND,"Task"+""+id+""+"does not exit")
        );
    }
}

