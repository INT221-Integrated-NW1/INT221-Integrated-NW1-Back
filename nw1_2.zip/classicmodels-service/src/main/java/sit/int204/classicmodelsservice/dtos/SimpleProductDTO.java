package sit.int204.classicmodelsservice.dtos;

public class SimpleProductDTO {
    private String productCode;
}
