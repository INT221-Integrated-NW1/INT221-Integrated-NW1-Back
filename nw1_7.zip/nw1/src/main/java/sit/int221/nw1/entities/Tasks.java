package sit.int221.nw1.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import sit.int221.nw1.enums.TaskStatus;

import java.time.Instant;

@Getter
@Setter
@Entity
@Table(name = "tasks")

public class Tasks {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "task_id")
    private Integer id;
    @Column(name = "task_title")
    private String title;
    @Column(name = "task_description")
    private String description;
    @Column(name = "task_assignees")
    private String assignees;
    @Enumerated(EnumType.STRING)
    @Column(name = "task_status")
    private TaskStatus status;
    @Column(name = "created_on")
    private Instant createdOn;
    @Column(name = "updated_on")
    private Instant updatedOn;
}

