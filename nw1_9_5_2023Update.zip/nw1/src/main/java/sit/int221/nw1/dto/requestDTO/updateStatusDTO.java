package sit.int221.nw1.dto.requestDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class updateStatusDTO {
    private Integer id;
    private String name;
    private String description;

    // Getters and setters...
}