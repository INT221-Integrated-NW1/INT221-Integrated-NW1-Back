package sit.int221.nw1.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class TaskDTO {
    private Integer task_id;
    private String task_title;
    private String task_description;
    private String task_assignees;
    private String task_status;
}
