package sit.int221.nw1.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;
@Getter
@Setter
public class TasksDTO {
    private Integer id;
    private String title;
    private String description;
    private String assignees;
    private String status;
    private Date createdOn;
    private Date updatedOn;
}