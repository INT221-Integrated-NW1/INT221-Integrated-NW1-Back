package sit.int221.nw1.requestDTO;
import lombok.Getter;
import lombok.Setter;
import sit.int221.nw1.enums.TaskStatus;

@Getter
@Setter
public class deleteDTO {
    private Integer id;
    private String title;
    private String assignees;
    private TaskStatus status;
}

