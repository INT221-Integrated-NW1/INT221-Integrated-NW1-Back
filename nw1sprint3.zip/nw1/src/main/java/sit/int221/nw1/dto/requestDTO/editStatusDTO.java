package sit.int221.nw1.dto.requestDTO;

public class editStatusDTO {
}
