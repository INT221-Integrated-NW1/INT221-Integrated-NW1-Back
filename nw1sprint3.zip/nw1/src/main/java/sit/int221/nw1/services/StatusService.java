package sit.int221.nw1.services;



import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sit.int221.nw1.Utils.StringUtil;
import sit.int221.nw1.dto.requestDTO.addStatusDTO;
import sit.int221.nw1.entities.Status;
import sit.int221.nw1.entities.Tasks;
import sit.int221.nw1.exception.ItemNotFoundException;
import sit.int221.nw1.repositories.StatusRepository;

import java.util.List;
@Service
public class StatusService {
    @Autowired
    ModelMapper modelMapper;
    @Autowired
    StatusRepository repository;

    public List<Status> getAllStatus() {
        return repository.findAll();
    }

    public Status createStatus(addStatusDTO addStatusDTO){
        Status status = modelMapper.map(addStatusDTO , Status.class);
        trim(status);
        return repository.save(status);
    }
    
    //trim method
    private void trim(Status status){
        status.setName(StringUtil.trimToNull(status.getName()));
        status.setDescription(StringUtil.trimToNull(status.getDescription()));
    }
    public Status deleteStatus(Integer id) {
        Status status = repository.findById(id).orElseThrow(
                () -> new ItemNotFoundException("NOT FOUND"
                ));
        repository.deleteById(id);
        return status;
    }
}
