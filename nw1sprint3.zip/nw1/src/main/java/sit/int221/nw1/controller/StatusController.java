package sit.int221.nw1.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import sit.int221.nw1.dto.requestDTO.addStatusDTO;
import sit.int221.nw1.dto.requestDTO.addDTO;
import sit.int221.nw1.dto.requestDTO.deleteStatusDTO;
import sit.int221.nw1.dto.responseDTO.StatusDTO;
import sit.int221.nw1.entities.Status;
import sit.int221.nw1.entities.Tasks;
import sit.int221.nw1.services.StatusService;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin(origins = {"http://localhost:5173", "http://ip23nw1.sit.kmutt.ac.th:3000"})
@RequestMapping("/v2/status")
public class StatusController {
    @Autowired
    StatusService statusService;
    @Autowired
    ModelMapper modelMapper;

    @GetMapping("")
    public ResponseEntity<Object> getAllStatus() {
        List<Status> status = statusService.getAllStatus();
        List<StatusDTO> statusDTO = status.stream()
                .map(task -> modelMapper.map(task, StatusDTO.class))
                .collect(Collectors.toList());
        return ResponseEntity.ok(statusDTO);
    }

    @PostMapping("")
    public ResponseEntity<Object> CreateStatus(@RequestBody addStatusDTO addStatusDTO) {
        Status newStatus = statusService.createStatus(addStatusDTO);
        addStatusDTO addnewStatus = modelMapper.map(newStatus, addStatusDTO.class);
        URI location = URI.create("");
        return ResponseEntity.created(location).body(addnewStatus);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteTask(@PathVariable Integer id) {
        Status deleteStatus = statusService.deleteStatus(id);
        deleteStatusDTO delete = modelMapper.map(deleteStatus, deleteStatusDTO.class);
        return ResponseEntity.ok(delete);
    }

}
