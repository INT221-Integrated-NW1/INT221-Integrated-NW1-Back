package sit.int221.nw1.enums;

import lombok.Getter;

@Getter
public enum TaskStatus {
    NO_STATUS,TO_DO,DOING,DONE;

}

