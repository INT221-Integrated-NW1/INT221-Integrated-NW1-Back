package sit.int221.nw1.services;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;

import org.springframework.web.server.ResponseStatusException;
import sit.int221.nw1.entities.Tasks;
import sit.int221.nw1.enums.TaskStatus;
import sit.int221.nw1.repositories.TasksRepository;
import sit.int221.nw1.requestDTO.addDTO;

import java.util.List;

@Service
public class TasksService {
    @Autowired
    ModelMapper modelMapper;
    @Autowired
    private TasksRepository repository;

    public List<Tasks> getAllTasks() {
        return repository.findAll();
    }

    public Tasks findById(Integer id){
        Tasks tasks = repository.findById(id).orElseThrow(
                ()-> new ResponseStatusException(HttpStatus.NOT_FOUND,"Task"+" "+id+" "+"does not exist")
        );
        //ห้ามลบ!!!
//        tasks.setCreatedOn(convertUTC(tasks.getCreatedOn()));
//        tasks.setUpdatedOn(convertUTC(tasks.getUpdatedOn()));
        return tasks;
    }
        //ห้ามลบ!!!
//    private LocalDateTime convertUTC(LocalDateTime localDateTime){
//        ZonedDateTime zonedDateTime = localDateTime.atZone(ZoneId.systemDefault());
//        ZonedDateTime utcDateTime = zonedDateTime.withZoneSameInstant(ZoneId.of("UTC"));
//        return utcDateTime.toLocalDateTime();
//    }

    public Tasks createTask(addDTO adddto){
        Tasks tasks = modelMapper.map(adddto , Tasks.class);
        tasks.setStatus(tasks.getStatus()==null ? TaskStatus.NO_STATUS:tasks.getStatus());
        return repository.save(tasks);
    }

}

