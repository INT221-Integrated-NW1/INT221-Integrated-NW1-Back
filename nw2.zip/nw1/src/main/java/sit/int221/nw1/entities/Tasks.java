package sit.int221.nw1.entities;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import sit.int221.nw1.enums.TaskStatus;

import java.sql.Timestamp;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@Table(name = "tasks")

public class Tasks {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "task_id")
    private Integer id;
    @Column(name = "task_title",nullable = false)
    private String title;
    @Column(name = "task_description")
    private String description;
    @Column(name = "task_assignees")
    private String assignees;
    @Enumerated(EnumType.STRING)
    @Column(name = "task_status")
    private TaskStatus status;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'",timezone = "UTC")
    @Column(name = "created_on",insertable = false,updatable = false)
    private LocalDateTime createdOn;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'",timezone = "UTC")
    @Column(name = "updated_on",insertable = false,updatable = false)
    private LocalDateTime updatedOn;
}

