package sit.int221.nw1.services;

import org.modelmapper.ModelMapper;

import java.util.List;
import java.util.stream.Collectors;

public class ListMapper {
    private static final ListMapper listMapper = new ListMapper();

    private ListMapper() {
    }
    public static ListMapper getInstance() {
        return listMapper;
    }

}
