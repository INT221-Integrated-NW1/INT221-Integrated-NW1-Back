package sit.int221.nw1.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sit.int221.nw1.entities.Tasks;
import sit.int221.nw1.repositories.TasksRepository;

import java.util.List;

@Service
public class TasksService {
    @Autowired
    private TasksRepository repository;

    public List<Tasks> getAllTasks() {
        return repository.findAll();
    }
}

