package sit.int221.nw1.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sit.int221.nw1.dto.TasksDTO;
import sit.int221.nw1.entities.Tasks;
import sit.int221.nw1.services.ListMapper;
import sit.int221.nw1.services.TasksService;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/tasks")
public class TasksController {
    @Autowired
    TasksService service;
    @Autowired
    ModelMapper modelMapper;
    @Autowired
    ListMapper listMapper;

    @GetMapping("")
    public ResponseEntity<Object> getAllTasks() {
        List<Tasks> task = service.getAllTasks();
        List<TasksDTO> TasksDTO = task.stream().map(s -> modelMapper.map(s, TasksDTO.class)).collect(Collectors.toList());
        return ResponseEntity.ok(TasksDTO);
    }
//    @GetMapping("/{id}")
//    public ResponseEntity<Object> getCustomerById(@PathVariable Integer id) {
//        Customer customer = service.findByID(id);
//        SimpleCustomerDTO simpleCustomer = modelMapper.map(customer, SimpleCustomerDTO.class);
//        return ResponseEntity.ok(simpleCustomer);
//    }
}
