package sit.int221.nw1.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;
@Getter
@Setter
public class TasksDTO {
    private Integer taskId;
    private String taskTitle;
    private String taskDescription;
    private String taskAssignees;
    private String taskStatus;
    private Date createdOn;
    private Date updatedOn;
}
