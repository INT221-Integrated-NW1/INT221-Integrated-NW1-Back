package sit.int221.nw1.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.Instant;
@Getter
@Setter
public class TasksDTO {
    private Integer id;
    private String title;
    private String description;
    private String assignees;
    private String status;
    private Instant createdOn;
    private Instant updatedOn;


}