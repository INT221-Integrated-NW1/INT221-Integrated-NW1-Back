package sit.int221.nw1.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import sit.int221.nw1.dto.TaskDTO;
import sit.int221.nw1.dto.TasksDTO;
import sit.int221.nw1.entities.Tasks;
import sit.int221.nw1.services.ListMapper;
import sit.int221.nw1.services.TasksService;

import java.util.List;
import java.util.stream.Collectors;
@CrossOrigin(origins = "http://ip23nw1.sit.kmutt.ac.th:3000")
@RestController
@RequestMapping("/tasks")
public class TasksController {
    @Autowired
    TasksService service;
    @Autowired
    ModelMapper modelMapper;
    @Autowired
    ListMapper listMapper;



    @GetMapping("")
    public ResponseEntity<Object> getAllTasks() {
        List<Tasks> tasks = service.getAllTasks();
        List<TaskDTO> tasksDTO = tasks.stream()
                .map(task -> modelMapper.map(task, TaskDTO.class))
                .collect(Collectors.toList());
        return ResponseEntity.ok(tasksDTO);
    }

    @PostMapping("/insert")
    public List<Tasks> createTask(@RequestBody List<Tasks> tasks){
        return service.insertTask(tasks);
    }


    @GetMapping("/{id}")
    public ResponseEntity<TasksDTO> getTaskById(@PathVariable Integer id) {
        Tasks task = service.findById(id);
        if (task != null) {
            TasksDTO tasksDTO = modelMapper.map(task, TasksDTO.class);
            return ResponseEntity.ok(tasksDTO);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
