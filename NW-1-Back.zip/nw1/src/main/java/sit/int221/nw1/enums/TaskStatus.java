package sit.int221.nw1.enums;

import lombok.Getter;

@Getter
public enum TaskStatus {
    No_Status, To_Do, Doing, Done;

}

