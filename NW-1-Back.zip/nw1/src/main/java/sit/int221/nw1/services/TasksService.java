package sit.int221.nw1.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;

import org.springframework.web.server.ResponseStatusException;
import sit.int221.nw1.entities.Tasks;
import sit.int221.nw1.repositories.TasksRepository;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;

@Service
public class TasksService {
    @Autowired
    private TasksRepository repository;

    public List<Tasks> getAllTasks() {
        return repository.findAll();
    }

    public Tasks findById(Integer id){
        Tasks tasks = repository.findById(id).orElseThrow(
                ()-> new ResponseStatusException(HttpStatus.NOT_FOUND,"Task"+" "+id+" "+"does not exit")
        );
//        tasks.setCreatedOn(convertUTC(tasks.getCreatedOn()));
//        tasks.setUpdatedOn(convertUTC(tasks.getUpdatedOn()));
        return tasks;
    }

//    private LocalDateTime convertUTC(LocalDateTime localDateTime){
//        ZonedDateTime zonedDateTime = localDateTime.atZone(ZoneId.systemDefault());
//        ZonedDateTime utcDateTime = zonedDateTime.withZoneSameInstant(ZoneId.of("UTC"));
//        return utcDateTime.toLocalDateTime();
//    }

    public List<Tasks> insertTask(List<Tasks>tasks){
        return repository.saveAll(tasks);
    }

}

