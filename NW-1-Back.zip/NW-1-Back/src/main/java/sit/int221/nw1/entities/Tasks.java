package sit.int221.nw1.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
@Getter
@Setter
@Entity
@Table(name = "tasks")

public class Tasks {
    @Id
    @Column(name = "task_id")
    private Integer task_id;
    @Column(name = "task_title")
    private String task_title;
    @Column(name = "task_description")
    private String task_description;
    @Column(name = "task_assignees")
    private String task_assignees;
    @Column(name = "task_status")
    private String task_status;
    private Date created_on;
    private Date updated_on;
}

