package sit.int221.nw1.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import sit.int221.nw1.dto.requestDTO.*;
import sit.int221.nw1.dto.responseDTO.StatusDTO;
import sit.int221.nw1.entities.Status;
import sit.int221.nw1.entities.Tasks;
import sit.int221.nw1.exception.ItemNotFoundException;
import sit.int221.nw1.services.StatusService;
import sit.int221.nw1.services.TasksService;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@CrossOrigin(origins = {"http://localhost:5173", "http://ip23nw1.sit.kmutt.ac.th:3000"})
@RequestMapping("/v2/status")
public class StatusController {
    @Autowired
    StatusService statusService;
    @Autowired
    ModelMapper modelMapper;
    @Autowired
    TasksService tasksService;

    @GetMapping("")
    public ResponseEntity<Object> getAllStatus() {
        List<Status> status = statusService.getAllStatus();
        List<StatusDTO> statusDTO = status.stream()
                .map(task -> modelMapper.map(task, StatusDTO.class))
                .collect(Collectors.toList());
        return ResponseEntity.ok(statusDTO);
    }

    @PostMapping("")
    public ResponseEntity<Object> CreateStatus(@RequestBody addStatusDTO addStatusDTO) {
        Status newStatus = statusService.createStatus(addStatusDTO);
        addStatusDTO addnewStatus = modelMapper.map(newStatus, addStatusDTO.class);
        URI location = URI.create("");
        return ResponseEntity.created(location).body(addnewStatus);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteTask(@PathVariable Integer id) {
        Status deleteStatus = statusService.deleteStatus(id);
        deleteStatusDTO delete = modelMapper.map(deleteStatus, deleteStatusDTO.class);
        return ResponseEntity.ok(delete);
    }

    @DeleteMapping("/{oldStatusId}/{newStatusId}")
    public ResponseEntity<Object> transferAndDelete(@PathVariable Integer oldStatusId, @PathVariable Integer newStatusId) {
        try {
            // Transfer tasks from the to-delete status to the destination status
            tasksService.transferTasks(oldStatusId, newStatusId);

            // Delete the to-delete status
            statusService.deleteStatus(oldStatusId);

            return new ResponseEntity<>("The task(s) have been transferred and the status has been deleted", HttpStatus.OK);
        } catch (ItemNotFoundException e) {
            return new ResponseEntity<>("An error has occurred, the status does not exist.", HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>("Error during transfer and delete operation: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @PutMapping("/{id}")
    public ResponseEntity<Object> updateStatus(@RequestBody updateStatusDTO updateStatusDTO) {
        Status updatedStatus = statusService.updateStatus(updateStatusDTO);
        return new ResponseEntity<>(updatedStatus, HttpStatus.OK);
    }
}
