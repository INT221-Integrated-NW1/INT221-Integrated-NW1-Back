package sit.int221.nw1.services;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import org.springframework.web.server.ResponseStatusException;
import sit.int221.nw1.entities.Tasks;
import sit.int221.nw1.enums.TaskStatus;
import sit.int221.nw1.exception.ItemNotFoundException;
import sit.int221.nw1.repositories.TasksRepository;
import sit.int221.nw1.requestDTO.addDTO;

import java.util.List;

@Service
public class TasksService {
    @Autowired
    ModelMapper modelMapper;
    @Autowired
    private TasksRepository repository;

    public List<Tasks> getAllTasks() {
        return repository.findAll();
    }

    public Tasks findById(Integer id){
        return repository.findById(id).orElseThrow(
                ()-> new ResponseStatusException(HttpStatus.NOT_FOUND,"Task"+" "+id+" "+"does not exist")
        );

    }


    public Tasks createTask(addDTO adddto){
        Tasks tasks = modelMapper.map(adddto , Tasks.class);
        trim(tasks);
        tasks.setStatus(tasks.getStatus()==null ? TaskStatus.NO_STATUS:tasks.getStatus());
        return repository.save(tasks);
    }

    public Tasks updateTask(Tasks updateDTOTask){
         Tasks tasks = modelMapper.map(updateDTOTask , Tasks.class);
         trim(tasks);
        tasks.setStatus(tasks.getStatus()==null ? TaskStatus.NO_STATUS : tasks.getStatus());
       return repository.save(tasks);
    }

    private void trim(Tasks tasks){
     tasks.setTitle(tasks.getTitle() != null ? tasks.getTitle().trim():null);
     tasks.setDescription(tasks.getDescription() != null ? tasks.getDescription().trim() : null);
     tasks.setAssignees(tasks.getAssignees() != null ? tasks.getAssignees().trim() : null);
    }

    // task(id) does not exist, e.g. has already been deleted by another user returns 404 from TaskNotFoundException class
    public Tasks deleteTask(Integer id){
        Tasks task = repository.findById(id).orElseThrow(
                ()-> new ItemNotFoundException("NOT FOUND"
                ));
        repository.deleteById(id);
        return task;
    }
}

