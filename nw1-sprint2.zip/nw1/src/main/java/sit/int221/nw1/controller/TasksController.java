package sit.int221.nw1.controller;

import jakarta.validation.Valid;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import sit.int221.nw1.dto.TaskDTO;
import sit.int221.nw1.dto.TasksDTO;
import sit.int221.nw1.entities.Tasks;
import sit.int221.nw1.requestDTO.addDTO;
import sit.int221.nw1.requestDTO.updateDTO;
import sit.int221.nw1.services.ListMapper;
import sit.int221.nw1.services.TasksService;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

@CrossOrigin(origins = {"http://localhost:5173", "http://ip23nw1.sit.kmutt.ac.th:3000"})
@RestController
@RequestMapping("/tasks")
public class TasksController {
    @Autowired
    TasksService service;
    @Autowired
    ModelMapper modelMapper;
    @Autowired
    ListMapper listMapper;


    @GetMapping("")
    public ResponseEntity<Object> getAllTasks() {
        List<Tasks> tasks = service.getAllTasks();
        List<TaskDTO> tasksDTO = tasks.stream()
                .map(task -> modelMapper.map(task, TaskDTO.class))
                .collect(Collectors.toList());
        return ResponseEntity.ok(tasksDTO);
    }

    @GetMapping("/{id}")
    public ResponseEntity<TasksDTO> getTaskById(@PathVariable Integer id) {
        Tasks task = service.findById(id);
        if (task != null) {
            TasksDTO tasksDTO = modelMapper.map(task, TasksDTO.class);
            return ResponseEntity.ok(tasksDTO);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/insert")
    public ResponseEntity<Object> CreateTask( @RequestBody addDTO adddtO) {
        Tasks createnewtask = service.createTask(adddtO);
        addDTO createdto = modelMapper.map(createnewtask , addDTO.class);
        URI location =URI.create("");
    return ResponseEntity.created(location).body(createdto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<updateDTO> updatetask(@RequestBody addDTO adddto , @PathVariable Integer id){
        Tasks update =service.findById(id);
        updateDTO updateDTOtask = modelMapper.map(update , updateDTO.class);
        update.setTitle(adddto.getTitle());
        update.setDescription(adddto.getDescription());
        update.setAssignees(adddto.getAssignees());
        update.setStatus(adddto.getStatus());
        service.updateTask(update);
        return ResponseEntity.ok().body(updateDTOtask);
    }

}
